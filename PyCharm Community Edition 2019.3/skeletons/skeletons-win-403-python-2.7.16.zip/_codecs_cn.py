# encoding: utf-8
# module _codecs_cn
# from (built-in)
# by generator 1.147
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    """  """
    pass

# no classes
# variables with complex values

__map_gb18030ext = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x00000000020C7330>'

__map_gb2312 = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x00000000020C7480>'

__map_gbcommon = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x00000000020C72D0>'

__map_gbkext = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x00000000020C75D0>'

