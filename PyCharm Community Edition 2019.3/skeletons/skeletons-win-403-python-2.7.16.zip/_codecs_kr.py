# encoding: utf-8
# module _codecs_kr
# from (built-in)
# by generator 1.147
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    """  """
    pass

# no classes
# variables with complex values

__map_cp949 = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x000000000221BB40>'

__map_cp949ext = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x000000000221BA80>'

__map_ksx1001 = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x000000000221BAE0>'

