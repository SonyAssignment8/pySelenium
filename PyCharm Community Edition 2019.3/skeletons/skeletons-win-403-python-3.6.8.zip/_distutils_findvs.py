# encoding: utf-8
# module _distutils_findvs
# from (pre-generated)
# by generator 1.147
""" The _distutils_findvs helper module """
# no imports

# functions

def findall(): # real signature unknown; restored from __doc__
    """ findall()Finds all installed versions of Visual Studio.This function will initialize COM temporarily. To avoid impact on other partsof your application, use a new thread to make this call. """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x0000020A9F201DA0>'

__spec__ = None # (!) real value is "ModuleSpec(name='_distutils_findvs', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x0000020A9F201DA0>, origin='C:\\\\BuildAgent\\\\system\\\\.persistent_cache\\\\pythons\\\\python36\\\\DLLs\\\\_distutils_findvs.pyd')"

